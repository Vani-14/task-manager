import sys
import logging
import pymysql
import json
import os

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
db_name = os.environ['DB_NAME']
endpoint = os.environ['ENDPOINT']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# create the database connection outside of the handler to allow connections to be
# re-used by subsequent function invocations.
try:
    conn = pymysql.connect(host=endpoint, user=user_name, passwd=password, db=db_name)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")

def lambda_handler(event, context):
    """
    This function creates a new RDS database table and writes records to it
    """
    logger.info(event)
    try:
        task = event['task']
        description = task['description']
        status = task['status']
        date_time = task['datetime']
        if status:
            status = '1'
        else:
            status = '0'
   
        sql_string = f"insert into Tasks (Description,Status, DateTime) values('{description}', '{status}', '{date_time}')"
    
        with conn.cursor() as cur:
            cur.execute("create table if not exists Tasks ( ID int NOT NULL AUTO_INCREMENT, Description varchar(255) NOT NULL, Status TINYINT(1) NOT NULL, DateTime DATETIME NOT NULL, PRIMARY KEY (ID))")
            cur.execute(sql_string)
            conn.commit()
        conn.commit()
    except:
        return {
            'statusCode': 400,
            'body': json.dumps('Error datas')
        }

    return {
        'statusCode': 201,
        'body': json.dumps('Ok')
    }

