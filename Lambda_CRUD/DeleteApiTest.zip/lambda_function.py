import sys
import logging
import pymysql
import json
import os

# rds settings
user_name = os.environ['USER_NAME']
password = os.environ['PASSWORD']
db_name = os.environ['DB_NAME']
endpoint = os.environ['ENDPOINT']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

try:
    conn = pymysql.connect(host=endpoint, user=user_name, passwd=password, db=db_name)
except pymysql.MySQLError as e:
    logger.error("ERROR: Unexpected error: Could not connect to MySQL instance.")
    logger.error(e)
    sys.exit(1)

logger.info("SUCCESS: Connection to RDS for MySQL instance succeeded")

def lambda_handler(event, context):
    """
    This function creates a new RDS database table and writes records to it
    """
    logger.info("id to delete:")
    logger.info(event)
    try:
    
        _id = event["id"]
       
        sql_string = f"DELETE FROM Tasks WHERE ID={_id}"
    
        with conn.cursor() as cur:
            cur.execute("create table if not exists Tasks ( ID int NOT NULL AUTO_INCREMENT, Description varchar(255) NOT NULL, Status TINYINT(1) NOT NULL, DateTime DATETIME NOT NULL, PRIMARY KEY (ID))")
            cur.execute(sql_string)
            logger.info("The item was deleted from the database")
            conn.commit()
        conn.commit()
    except:
        logger.info("Error data rece")
        return {
        'statusCode': 400,
        'body': json.dumps("Error data received")
    }

    return {
        'statusCode': 200,
        'body': json.dumps("Item Deleted")
    }

